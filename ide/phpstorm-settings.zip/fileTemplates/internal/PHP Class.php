<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * 
 */
class ${FILE_NAME} {

  

  public function __construct() {
  
  }

  
}

/* End of file ${NAME}.php */
/* Location: ./application/ */